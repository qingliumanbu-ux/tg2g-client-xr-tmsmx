<template>

  <xr-ef-form @ready="efFormReady" :f2-do="F2_DO" :f3-do="F3_DO" :f3-pre-do="F3_PRE_DO" :f3-cancel="F3_CANCEL" :f4-do="F4_DO" :f4-pre-do="F4_PRE_DO" :f4-cancel="F4_CANCEL">
    <er-layout v-if="initializeFlag === 1" :er-form-helper-prop="erFormHelper" :config-id="`${layout}`"></er-layout>

    <div style="display: flex; flex-direction: row; width: 100%; height: 100%">
      <div style="width: 100%; height: 100%">
        <xr-ef-panel :title="`${c_name}`" padding="5px" style="height: 100%">
          <template #customButtonSlot></template>
          <template #contentSlot>
            <er-grid v-if="initializeFlag === 1" :er-form-helper-prop="erFormHelper" :config-id="`${gridview}`"
              :toolbar-style="'both'" :toolbar-options="gridToolbar" @focus-changed="gridView_focuse_changed"></er-grid>
          </template>
        </xr-ef-panel>
      </div>
    </div>
  </xr-ef-form>
</template>

<script lang="ts" src="./TMSM181AV"></script>

<style lang="scss" scoped>
@import "./TMSM181AV.scss";
</style>
